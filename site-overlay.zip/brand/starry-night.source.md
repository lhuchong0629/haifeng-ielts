# The Starry Night / 星月夜

Artist: Vincent van Gogh, 1889.
Source: https://commons.wikimedia.org/wiki/File:Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg
Digital reproduction: Google Art Project, via Wikimedia Commons (1280 px).
Public domain artwork and faithful reproduction, as marked by Wikimedia Commons.
This image is excluded from the project-generated illustration attribution in CONTENT_LICENSE.md.
